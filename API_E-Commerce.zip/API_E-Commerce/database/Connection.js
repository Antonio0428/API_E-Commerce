import knex from 'knex';

const config = {
  client: 'mysql2',
  connection: {
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '040494@idonia#',
    database: 'sysge',
  }
};

const Connection = knex(config);

export {Connection};