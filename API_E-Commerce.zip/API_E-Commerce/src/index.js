import express from 'express';
import cors from 'cors';
const app = express();

import { CategoriaRouter } from './router/Categoria.router.js';
import { ProdutoRouter } from './router/Produto.router.js';
import { SubprodutoRouter } from './router/Subproduto.router.js';
import { EstoqueRouter } from './router/Estoque.router.js';
import { VendaRouter } from './router/Venda.router.js';
import { FuncaoRouter } from './router/Funcao.router.js';
import { CarrinhoRouter } from './router/Carrinho.router.js';
import { ItemCarrinhoRouter } from './router/ItemCarrinho.router.js';

app.use(express.json())
app.use(cors())
//Usando as nossas rotas
app.use(CategoriaRouter)
app.use(ProdutoRouter)
app.use(SubprodutoRouter)
app.use(EstoqueRouter)
app.use(VendaRouter)
app.use(FuncaoRouter)
app.use(CarrinhoRouter)
app.use(ItemCarrinhoRouter)

//Usando os nossos modelos

app.listen(3000,()=>{
    console.log('Servidor na porta 3000');
})

