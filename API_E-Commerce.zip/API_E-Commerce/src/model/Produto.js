import { Connection } from "../../database/Connection.js";
class Produto{

//FUNÇÃO DAS ROTAS
    async insert(nome, precoMedio, descricão, categoriaId){
        const data = {
            nome,
            precoMedio,
            descricão,
            categoriaId
        }
        try {
            return await Connection.insert(data).into('produto') 
        } catch (error) {
            return error
        }
    }
    async update(id,nome, precoMedio, descricão, categoriaId){
        const data = {
            nome,
            precoMedio,
            descricão,
            categoriaId
        }
        try {
            return await Connection.update(data).where({id: id}).table('produto')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('produto')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('produto')
        } catch (error) {
            return error
        }
    }
    
//METODO DE SELEÇÃO ESPECÍFICA
    async selectNomeProduto(nome){
        console.log("Nome: ", nome);
        try {
            return await Connection.select('*').where({nome: nome}).table('produto')
        } catch (error) {
            return error
        }
    }
    async selectIdProduto(id){
        console.log("Id: ", id);
        try {
            return await Connection.select('*').where({id: id}).table('produto')
        } catch (error) {
            return error
        }
    }

    async selectInnerJoin(){
        try {
            return await Connection.select(["produto.nome", "produto.precoMedio", "subproduto.nome as subproduto"])
                .table('produto')
                    .innerJoin("subproduto","subproduto.id", "produto.categoriaId")
        } catch (error) {
            return error
        }
    }
    async selectIdInnerJoin(id){
        console.log("IdProduto: ", id);
        
        try {
            return await Connection.select(["produto.nome", "produto.precoMedio", "subproduto.nome as subproduto"])
                .table('produto')
                    .innerJoin("subproduto","subproduto.id", "produto.categoriaId").where("produto.id", id)
        } catch (error) {
            return error
        }
    }
}

export { Produto }