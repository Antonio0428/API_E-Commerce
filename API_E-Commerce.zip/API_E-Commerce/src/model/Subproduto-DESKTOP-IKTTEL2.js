
import { Connection } from "../../database/Connection.js";
class Subproduto {
    
    async insert(nome, peso, tamanho, cor, preco, descricão, produtoId){
        const data = {
            nome,
            peso,
            tamanho,
            cor,
            preco,
            descricão,
            produtoId
        }
        try {
            return await Connection.insert(data).into('subproduto') 
        } catch (error) {
            return error
        }
    }
    async update(id, nome, peso, tamanho, cor, preco, descricão, produtoId){
        const data = {
            nome,
            peso,
            tamanho,
            cor,
            preco,
            descricão,
            produtoId
        }
        try {
            return await Connection.update(data).where({id: id}).table('subproduto')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('subproduto')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('subproduto')
        } catch (error) {
            return error
        }
    }
    //METODO DE SELEÇÃO ESPECÍFICA
    async selectNomeSubproduto(nome){
        console.log("Nome: ", nome);
        try {
            return await Connection.select('*').where({nome: nome}).table('subproduto')
        } catch (error) {
            return error
        }
    }
    async selectIdSubproduto(id){
        console.log("Id: ", id);
        try {
            return await Connection.select('*').where({id: id}).table('subproduto')
        } catch (error) {
            return error
        }
    }
    async selectInnerJoin(){
        try {
            return await Connection.select(["subproduto.id","subproduto.nome", "subproduto.descricão", "produto.nome as produto", "produto.id as produtoId"])
                .table('subproduto')
                    .innerJoin("produto","produto.id", "subproduto.produtoId")
        } catch (error) {
            return error
        }
    }
    async selectIdInnerJoin(id){
        console.log("IdProduto: ", id);
        
        try {
            return await Connection.select(["subproduto.nome", "subproduto.preco", "produto.nome as produto", "produto.id as id"])
                .table('subproduto')
                    .innerJoin("produto","produto.id", "subproduto.produtoId")
                    .where("subproduto.produtoId", id)
        } catch (error) {
            return error
        }
    }
}

export { Subproduto }