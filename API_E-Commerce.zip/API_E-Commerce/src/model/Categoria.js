import { Connection } from "../../database/Connection.js";
import {v4 as uuidv4} from 'uuid'

class Categoria {
    //METODOS DE ACÇÕES GERAIS
    async insert(name){
        try {
            return await Connection.insert({nome: name}).into('categoriaproduto')
        } catch (error) {
            return error
        }
    }
    async update(nome, id){
        try {
            return await Connection.update({nome: nome}).where({id: id}).table('categoriaproduto')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('categoriaproduto')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('categoriaproduto')
        } catch (error) {
            return error
        }
    }

//METODO DE SELEÇÃO ESPECÍFICA
    async selectIdCategoria(id){
        console.log("Id: ", id);
        try {
            return await Connection.select('*').where({id: id}).table('categoriaproduto')
        } catch (error) {
            return error
        }
    }
    async selectNomeCategoria(nome){
        console.log("Nome: ", nome);
        try {
            return await Connection.select('*').where({nome: nome}).table('categoriaproduto')
        } catch (error) {
            return error
        }
    }
}

export {Categoria}