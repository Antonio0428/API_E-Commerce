
import { Connection } from "../../database/Connection.js";
class Itemcarrinho {
    
    async insert(produtoId, quantidade, carrinhoId){
        const data = {
            produtoId,
            quantidade,
            carrinhoId
        }
        try {
            return await Connection.insert(data).into('itemcarrinho') 
        } catch (error) {
            return error
        }
    }
    async update(id, produtoId, quantidade, carrinhoId){
        const data = {
            produtoId,
            quantidade,
            carrinhoId
        }
        try {
            return await Connection.update(data).where({id: id}).table('itemcarrinho')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('itemcarrinho')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('itemcarrinho')
        } catch (error) {
            return error
        }
    }
    //METODO DE SELEÇÃO ESPECÍFICA
    async selectCarrinhoItemcarrinho(produtoId){
        console.log("Nome: ", produtoId);
        try {
            return await Connection.select('*').where({carrinhoId: produtoId}).table('itemcarrinho')
        } catch (error) {
            return error
        }
    }
    async selectIdItemcarrinho(id){
        console.log("Id: ", id);
        try {
            return await Connection.select('*').where({id: id}).table('itemcarrinho')
        } catch (error) {
            return error
        }
    }
    async selectInnerJoin(){
        try {
            return await Connection.select(["itemcarrinho.nome", "itemcarrinho.preco", "produto.nome as produto", "produto.id as id"])
                .table('itemcarrinho')
                    .innerJoin("produto","produto.id", "itemcarrinho.produtoId")
        } catch (error) {
            return error
        }
    }
    async selectIdInnerJoin(id){
        console.log("IdProduto: ", id);
        
        try {
            return await Connection.select(["itemcarrinho.nome", "itemcarrinho.preco", "produto.nome as produto", "produto.id as id"])
                .table('itemcarrinho')
                    .innerJoin("produto","produto.id", "itemcarrinho.produtoId")
                    .where("itemcarrinho.produtoId", id)
        } catch (error) {
            return error
        }
    }
}

export { Itemcarrinho }