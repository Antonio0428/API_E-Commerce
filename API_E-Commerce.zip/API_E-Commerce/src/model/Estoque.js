import { Connection } from "../../database/Connection.js";
class Estoque{

//FUNÇÃO DAS ROTAS
    async insert(quantidade, produtoId){
        const data = {
            quantidade,
            produtoId
        }
        console.log(produtoId);
        
        try {
            return await Connection.insert(data).into('estoque') 
        } catch (error) {
            return error
        }
    }
    async update(id,nome, precoMedio, descricão, categoriaId){
        const data = {
            nome,
            precoMedio,
            descricão,
            categoriaId
        }
        try {
            return await Connection.update(data).where({id: id}).table('produto')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('produto')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('produto')
        } catch (error) {
            return error
        }
    }
//METODO DE SELEÇÃO ESPECÍFICA
    async selectNomeProduto(nome){
        console.log("Nome: ", nome);
        try {
            return await Connection.select('*').where({nome: nome}).table('produto')
        } catch (error) {
            return error
        }
    }
    async selectProdutoId(produtoId){
        console.log("Id: ", produtoId);
        try {
            return await Connection.select('*').where({produtoId: produtoId}).table('estoque')
        } catch (error) {
            return error
        }
    }

    async selectInnerJoin(){
        try {
            return await Connection.select(["produto.nome", "produto.precoMedio", "categoriaproduto.nome as categoria"])
                .table('produto')
                    .innerJoin("categoriaproduto","categoriaproduto.id", "produto.categoriaId")
        } catch (error) {
            return error
        }
    }
    async selectIdInnerJoin(id){
        console.log("IdProduto: ", id);
        
        try {
            return await Connection.select(["produto.nome", "produto.precoMedio", "categoriaproduto.nome as categoria"])
                .table('produto')
                    .innerJoin("categoriaproduto","categoriaproduto.id", "produto.categoriaId").where("produto.id", id)
        } catch (error) {
            return error
        }
    }
}

export { Estoque }