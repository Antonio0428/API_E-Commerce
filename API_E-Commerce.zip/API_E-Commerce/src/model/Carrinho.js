import { Connection } from "../../database/Connection.js";
class Carrinho {
    
    async insert(dataCriacao, funcionarioId){
        const data = {
            dataCriacao,
            funcionarioId
        }
        try {
            return await Connection.insert(data).into('carrinho') 
        } catch (error) {
            return error
        }
    }
    async update(id, dataCriacao, funcionarioId){
        const data = {
            dataCriacao,
            funcionarioId
        }
        try {
            return await Connection.update(data).where({id: id}).table('carrinho')
        } catch (error) {
            return error
        }
    }
    async select(){
        try {
            return await Connection.select('*').table('carrinho')
        } catch (error) {
            return error
        }
    }
    async delete(id){
        try {
            return await Connection.delete().where({id: id}).table('carrinho')
        } catch (error) {
            return error
        }
    }
    //METODO DE SELEÇÃO ESPECÍFICA
    async selectIdCarrinho(id){
        console.log("Id: ", id);
        try {
            return await Connection.select('*').where({id: id}).table('carrinho')
        } catch (error) {
            return error
        }
    }
    async selectInnerJoin(){
        try {
            return await Connection.select(["carrinho.preco", "funcionario.nome as cliente", "funcionario.id as id"])
                .table('carrinho')
                    .innerJoin("funcionario","funcionario.id", "carrinho.funcionarioId")
        } catch (error) {
            return error
        }
    }
    async selectIdInnerJoin(id){
        console.log("IdProduto: ", id);
        
        try {
            return await Connection.select(["carrinho.preco", "funcionario.nome as cliente", "funcionario.id as id"])
            .table('carrinho')
                .innerJoin("funcionario","funcionario.id", "carrinho.funcionarioId")
                    .where("carrinho.funcionarioId", id)
        } catch (error) {
            return error
        }
    }
}

export { Carrinho }