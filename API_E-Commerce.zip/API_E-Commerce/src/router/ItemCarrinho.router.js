import { Router }  from 'express';
const ItemCarrinhoRouter = Router()
import { ItemCarrinhoController } from '../controller/ItemCarrinhoController.js';
const itemcarrinho = new ItemCarrinhoController()

//ROTA DA CATEGORIA
ItemCarrinhoRouter.post('/itemcarrinho', itemcarrinho.verifyData,itemcarrinho.insert)
ItemCarrinhoRouter.put('/itemcarrinho', itemcarrinho.verifyIdParams, itemcarrinho.verifyData, itemcarrinho.update)
ItemCarrinhoRouter.get('/itemcarrinho/:id', itemcarrinho.verifyIdParams, itemcarrinho.selectById)
ItemCarrinhoRouter.get('/itemcarrinho', itemcarrinho.select)
ItemCarrinhoRouter.delete('/itemcarrinho/:id', itemcarrinho.verifyIdParams, itemcarrinho.delete)
export {ItemCarrinhoRouter}