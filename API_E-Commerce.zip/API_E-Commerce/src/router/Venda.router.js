import { Router }  from 'express';
const VendaRouter = Router()
import { VendaController } from '../controller/VendaController.js';
const venda = new VendaController()

//ROTA DE SUBPRODUTO
VendaRouter.post('/venda', venda.verifyData, venda.insert)
VendaRouter.put('/venda/:id', venda.verifyData, venda.verifyIdParams, venda.update)
VendaRouter.get('/venda/prod', venda.selectInnerJoin)
VendaRouter.get('/venda', venda.select)
VendaRouter.get('/venda/:id', venda.verifyIdParams, venda.selectById)
VendaRouter.get('/venda/join/:id', venda.verifyIdParams, venda.selectIdInnerJoin)
VendaRouter.delete('/venda/:id', venda.verifyIdParams, venda.delete)

export {VendaRouter}