import { Router }  from 'express';
const EstoqueRouter = Router()
import { EstoqueController } from '../controller/EstoqueController.js';
const estoque = new EstoqueController()

//ROTA DA CATEGORIA
EstoqueRouter.post('/estoque', estoque.verifyData,estoque.insert)

export { EstoqueRouter}