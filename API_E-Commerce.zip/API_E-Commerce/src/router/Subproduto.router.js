import { Router }  from 'express';
const SubprodutoRouter = Router()
import { SubprodutoController } from '../controller/SubprodutoController.js';
const subproduto = new SubprodutoController()

//ROTA DE SUBPRODUTO
SubprodutoRouter.post('/subproduto', subproduto.verifyData, subproduto.insert)
SubprodutoRouter.put('/subproduto/:id', subproduto.verifyData, subproduto.verifyIdParams, subproduto.update)
SubprodutoRouter.get('/subproduto/prod', subproduto.selectInnerJoin)
SubprodutoRouter.get('/subproduto', subproduto.select)
SubprodutoRouter.get('/subproduto/:id', subproduto.verifyIdParams, subproduto.selectById)
SubprodutoRouter.get('/subproduto/join/:id', subproduto.verifyIdParams, subproduto.selectIdInnerJoin)
SubprodutoRouter.delete('/subproduto/:id', subproduto.verifyIdParams, subproduto.delete)

export {SubprodutoRouter}