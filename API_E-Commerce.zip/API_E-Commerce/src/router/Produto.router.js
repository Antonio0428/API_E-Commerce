import { Router }  from 'express';
const ProdutoRouter = Router()
import { ProdutoController } from '../controller/ProdutoController.js';
const produto = new ProdutoController()


//ROTA DE PRODUTO
ProdutoRouter.post('/produto', produto.nomeExist, produto.insert)
ProdutoRouter.put('/produto/:id', produto.idExistParams,produto.nomeExist, produto.update)
ProdutoRouter.get('/produto/categ', produto.selectInnerJoin)
ProdutoRouter.get('/produto/:id', produto.idExistParams, produto.selectById)
ProdutoRouter.get('/produto', produto.select)
ProdutoRouter.get('/produto/join/:id', produto.idExistParams, produto.selectIdInnerJoin)
ProdutoRouter.delete('/produto/:id', produto.idExistParams, produto.delete)

export {ProdutoRouter}