import { Router }  from 'express';
const CarrinhoRouter = Router()
import { CarrinhoController } from '../controller/CarrinhoController.js';
const carrinho = new CarrinhoController()

//ROTA DA CATEGORIA
CarrinhoRouter.post('/carrinho', carrinho.verifyData,carrinho.insert)
CarrinhoRouter.put('/carrinho', carrinho.verifyIdParams, carrinho.verifyData, carrinho.update)
CarrinhoRouter.get('/carrinho/:id', carrinho.verifyIdParams, carrinho.selectById)
CarrinhoRouter.get('/carrinho', carrinho.select)
CarrinhoRouter.delete('/carrinho/:id', carrinho.verifyIdParams, carrinho.delete)
export {CarrinhoRouter}