import { Router }  from 'express';
const FuncaoRouter = Router()
import { FuncaoController } from '../controller/FuncaoController.js';
const funcao = new FuncaoController()

//ROTA DA CATEGORIA
FuncaoRouter.post('/funcao', funcao.nomeExist,funcao.insert)
FuncaoRouter.put('/funcao', funcao.idExist,funcao.nomeExist, funcao.update)
FuncaoRouter.get('/funcao/:id', funcao.idExistParams, funcao.selectById)
FuncaoRouter.get('/funcao', funcao.select)
FuncaoRouter.delete('/funcao/:id', funcao.idExistParams, funcao.delete)

export {FuncaoRouter}