import { Router }  from 'express';
const CategoriaRouter = Router()
import { CategoriaController } from '../controller/CategoriaController.js';
const categoria = new CategoriaController()

//ROTA DA CATEGORIA
CategoriaRouter.post('/categoria', categoria.nomeExist,categoria.insert)
CategoriaRouter.put('/categoria', categoria.idExist,categoria.nomeExist, categoria.update)
CategoriaRouter.get('/categoria/:id', categoria.idExistParams, categoria.selectById)
CategoriaRouter.get('/categoria', categoria.select)
CategoriaRouter.delete('/categoria/:id', categoria.idExistParams, categoria.delete)
export {CategoriaRouter}