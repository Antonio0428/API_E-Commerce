import { Carrinho } from "../model/Carrinho.js";
const carrinho = new Carrinho()
class CarrinhoController{
    async verifyIdBody(req, res, next){
        var {id, funcionarioId} = req.body
        console.log("Id: ",id);
        if (isNaN(id) ||isNaN(funcionarioId)) {
            return res.json({erro: 'O id do cliente e do carrinho deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await carrinho.selectIdCarrinho(id)
                if (result.length > 0) {
                    req.id = id
                    req.funcionarioId = funcionarioId
                }else{
                    return res.json({erro: 'Carrinho não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyIdParams(req, res, next){
        var {id, funcionarioId} = req.params
        id = parseInt(id)
        funcionarioId = parseInt(funcionarioId)
        if (isNaN(id)) {
            return res.json({erro: 'O id do cliente e do carrinho deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await carrinho.selectIdCarrinho(id)
                if (result.length > 0) {
                    req.id = id
                    req.funcionarioId = funcionarioId
                }else{
                    return res.json({erro: 'Carrinho não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyData(req, res, next){
        var {funcionarioId} = req.body
        console.log("FuncId: ", funcionarioId);
        
        if(isNaN(funcionarioId)){
            return res.json({erro: 'O Id do cliente deve ser número e campo não deve estar vazio'})
        }else{
            req.funcionarioId = funcionarioId
            next()            
        }       
         
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {funcionarioId} = req
        console.log("Data: ", new Date());
        console.log("FuncId: ", funcionarioId);
        try {
            var result = await carrinho.insert(new Date(), funcionarioId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Carrinho inserida",result})
        }
    }
    async update(req, res){
        var {funcionarioId} = req 
        var {id} = req
        if (typeof(id) !== Number) {
            console.log("Is number:",id, ", TypeOf: ", typeof(id));
        }      
        try {
            var result = await carrinho.update(id, Date.now(), funcionarioId)
            return res.json({mensagem: 'Carrinho alterada',result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async select(req, res){  
        try {
            var result = await carrinho.select()
            return res.json({Carrinho: result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await carrinho.delete(id)
                return res.json({mensagem: "Carrinho deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
//FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await carrinho.selectIdCarrinho(id)
            return res.json({result})
        } catch (error) {
            return res.json({Carrinho: result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await carrinho.selectInnerJoin()
            return res.status(201).json({join: result})
        } catch (error) {
            return res.json({result})
        }
    }  
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await carrinho.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }  
    
}

export { CarrinhoController }