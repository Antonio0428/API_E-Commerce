import { Subproduto } from "../model/Subproduto.js"
const subproduto = new Subproduto()
class SubprodutoController{
    async verifyIdBody(req, res, next){
        var {produtoId} = req.body
        console.log("Id: ",id);
        
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await subproduto.selectIdSubproduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyIdParams(req, res, next){
        var {id} = req.params
        id = parseInt(id)
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await subproduto.selectIdSubproduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyData(req, res, next){
        var {nome, peso, tamanho, cor, preco, descricao, produtoId} = req.body
        console.log("Desc1: ",descricao); 
        if (typeof(nome) === "number" || nome === undefined || nome === "") {
            return res.json({erro: 'O nome do produto deve ser texto e campo não deve estar vazio'})
        }else if(typeof(descricao) === "number" || descricao === undefined || descricao === ""){
            return res.json({erro: 'A descrição do produto deve ser texto e campo não deve estar vazio'})
        }else if(isNaN(peso) || isNaN(preco) || isNaN(produtoId)){
            return res.json({erro: 'O preço, o peso e o Id do produto deve ser número e campo não deve estar vazio'})
        }else if (typeof(tamanho) === "number" || tamanho === undefined || tamanho === "") {
            return res.json({erro: 'O nome do produto deve ser texto e campo não deve estar vazio'})
        }else if(typeof(cor) === "number" || cor === undefined || cor === ""){
            return res.json({erro: 'A descrição do produto deve ser texto e campo não deve estar vazio'})
        }else if(typeof(descricao) === "number" || descricao === undefined || descricao === ""){
            return res.json({erro: 'O preço e o Id do produto deve ser número e campo não deve estar vazio'})
        }else{
            nome = nome.trim()
            preco = parseFloat(preco)
            descricao = descricao.trim()
            peso = parseFloat(peso)
            tamanho = tamanho.trim()
            cor = cor.trim()
            console.log("Desc2: ",nome); 
            try {
                var result = await subproduto.selectNomeSubproduto(nome)
                console.log("Desc3: ",nome);
                
                console.log("Desc3.1: ",nome);
                if (result.length <= 0) {
                    console.log("Desc4: ",nome);
                    req.nome = nome
                    req.preco = preco
                    req.descricao = descricao
                    req.produtoId = produtoId
                    req.peso = peso
                    req.tamanho = tamanho
                    req.cor = cor
                    console.log("Desc5: ",descricao); 

                }else{
                    return res.status(406).json({erro: 'Nome do produto já existe'})
                }
                next()            
            } catch (error) {
                return error
            }
        }       
         
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {nome, peso, tamanho, cor, preco, descricao, produtoId} = req
        try {
            var result = await subproduto.insert(nome, peso, tamanho, cor, preco, descricao, produtoId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Subroduto inserida",result})
        }
    }
    async update(req, res){
        var {nome, peso, tamanho, cor, preco, descricao, produtoId} = req 
        var {id} = req

        if (typeof(id) !== Number) {
            console.log("Is number:",id, ", TypeOf: ", typeof(id));
        }      
        try {
            var result = await subproduto.update(id, nome, peso, tamanho, cor, preco, descricao, produtoId)
            return res.json({mensagem: 'Subproduto alterada',result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async select(req, res){  
        try {
            var result = await subproduto.select()
            return res.json({subprodutos: result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await subproduto.delete(id)
                return res.json({mensagem: "Subproduto deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
//FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await subproduto.selectIdSubproduto(id)
            return res.json({result})
        } catch (error) {
            return res.json({subproduto: result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await subproduto.selectInnerJoin()
            return res.status(201).json({join: result})
        } catch (error) {
            return res.json({result})
        }
    }  
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await subproduto.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }  
    
}

export { SubprodutoController }