import { Categoria } from "../model/Categoria.js";
var categoria = new Categoria()
class CategoriaController{

//MIDDLEWARE
    async idExist(req, res, next){
        var {id} = req.body
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await categoria.selectIdCategoria(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({result: 'Categoria não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async idExistParams(req, res, next){
        var {id} = req.params
        id = parseInt(id)
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await categoria.selectIdCategoria(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({result: 'Categoria não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async nomeExist(req, res, next){
        var {nome} = req.body 
        if (typeof(nome) === "number" || nome === undefined || nome === "") {
            return res.json({erro: 'O nome da categoria deve ser texto ou campo não deve estar vazio'})
        }else{
            nome = nome.trim()
            try {
                var result = await categoria.selectNomeCategoria(nome)
                if (result.length <= 0) {
                    req.nome = nome
                }else{
                    return res.json({erro: 'Nome de Categoria já existe'})
                }
                next()            
            } catch (error) {
                return error
            }
        }       
         
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {nome} = req
        try {
            var result = await categoria.insert(nome)
            return res.json({mensagem: "Categoria inserida",result})
        } catch (error) {
            return res.json({error})
        }      
    }
    async update(req, res){
        var {nome} = req 
        var {id} = req

        if (typeof(id) !== Number) {
            console.log("Is number:",id, ", TypeOf: ", typeof(id));
        }      
        try {
            var result = await categoria.update(nome,id)
            return res.json({mensagem: 'Categoria alterada',result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async select(req, res){  
        try {
            var result = await categoria.select()
            return res.json({categorias:result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await categoria.delete(id)
                return res.json({mensagem: "Categoria deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
    async selectById(req, res){
        var {id} = req
            try {
                var result = await categoria.selectIdCategoria(id)
                if (result.length > 0) {
                    return res.json({categoria:result})
                }
                return res.json({result: 'Categoria não existente!'})
            } catch (error) {
                return res.json({error})
            }
         
    }

}
export {CategoriaController};