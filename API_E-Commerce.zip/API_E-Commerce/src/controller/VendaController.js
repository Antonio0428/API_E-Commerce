import { Venda } from "../model/Venda.js";
const venda = new Venda()
class VendaController{
    async verifyIdBody(req, res, next){
        var {produtoId} = req.body
        console.log("Id: ",id);
        
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await subproduto.selectIdSubproduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyIdParams(req, res, next){
        var {id} = req.params
        id = parseInt(id)
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await subproduto.selectIdSubproduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyData(req, res, next){
        var {funcionarioId, formaPagamento, valorTotal, desconto, clienteId} = req.body
        console.log("Desc1: ",desconto); 
        if (typeof(formaPagamento) === "number" || formaPagamento === undefined || formaPagamento === "") {
            return res.json({erro: 'A formaPagamento do produto deve ser texto e campo não deve estar vazio'})
        }else if(isNaN(funcionarioId) || isNaN(valorTotal) || isNaN(desconto)){
            return res.json({erro: 'O funcionarioId, o valorTotal, o clienteId, e o desconto do produto deve ser número e campo não deve estar vazio'})
        }
            formaPagamento = formaPagamento.trim()
            funcionarioId = parseFloat(funcionarioId)
            clienteId = parseFloat(clienteId)
            valorTotal = parseFloat(valorTotal)
            desconto =parseFloat(desconto)
            console.log("Desc2: ",desconto); 
            
                    console.log("Desc4: ",desconto);
                    req.formaPagamento = formaPagamento
                    req.funcionarioId = funcionarioId
                    req.clienteId = clienteId
                    req.desconto = desconto
                    req.valorTotal = valorTotal
                    console.log("Desc5: ",desconto); 
                next()            
                 
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {funcionarioId, formaPagamento, valorTotal, desconto} = req
        try {
            var result = await venda.insert(funcionarioId, formaPagamento, valorTotal, desconto)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Venda inserida",result: result})
        }
    }
    async update(req, res){
        var {nome, peso, tamanho, cor, preco, descricao, produtoId} = req 
        var {id} = req

        if (typeof(id) !== Number) {
            console.log("Is number:",id, ", TypeOf: ", typeof(id));
        }      
        try {
            var result = await subproduto.update(id, nome, peso, tamanho, cor, preco, descricao, produtoId)
            return res.json({mensagem: 'Subproduto alterada',result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async select(req, res){  
        try {
            var result = await subproduto.select()
            return res.json({vendas: result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await subproduto.delete(id)
                return res.json({mensagem: "Subproduto deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
//FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await subproduto.selectIdSubproduto(id)
            return res.json({venda:result})
        } catch (error) {
            return res.json({result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await subproduto.selectInnerJoin()
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }
    }  
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await subproduto.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }  
    
}

export { VendaController }