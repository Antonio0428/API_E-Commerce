import { Produto } from "../model/Produto.js"
var produto = new Produto()
class ProdutoController{

    //MIDDLEWARE
    async idExist(req, res, next){
        var {id} = req.body
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await produto.selectIdProduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async idExistParams(req, res, next){
        var {id} = req.params
        id = parseInt(id)
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await produto.selectIdProduto(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async nomeExist(req, res, next){
        var {nome, preco, descricao, categoriaId} = req.body
        
        if (typeof(nome) === "number" || nome === undefined || nome === "") {
            return res.json({erro: 'O nome do produto deve ser texto e campo não deve estar vazio'})
        }else if(typeof(descricao) === "number" || descricao === undefined || descricao === ""){
            return res.json({erro: 'A descrição do produto deve ser texto e campo não deve estar vazio'})
        }else if(isNaN(preco) || isNaN(categoriaId)){
            return res.json({erro: 'O preço e o Id do produto deve ser número e campo não deve estar vazio'})
        }else{
            nome = nome.trim()
            preco = parseFloat(preco)
            descricao = descricao.trim()
            console.log("Desc: ",descricao); 
            try {
                var result = await produto.selectNomeProduto(nome)
                if (result.length <= 0) {
                    req.nome = nome
                    req.preco = preco
                    req.descricao = descricao
                    req.categoriaId = categoriaId
                }else{
                    return res.json({erro: 'Nome do produto já existe'})
                }
                next()            
            } catch (error) {
                return error
            }
        }       
         
    }
//FUNÇÃO DAS ROTAS

    async insert(req, res){
        var {nome, preco, descricao, categoriaId} = req
        try {
            var result = await produto.insert(nome, preco, descricao, categoriaId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Produto inserida",result})
        }
    }
    async update(req, res){
        var {id, nome, preco, descricao, categoriaId} = req
        try {
            var result = await produto.update(id, nome, preco, descricao, categoriaId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Produto alterado",result})
        }
    }
    async select(req, res){  
        try {
            var result = await produto.select()
            return res.json({produtos:result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await produto.delete(id)
                return res.json({mensagem: "Produto deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
    //FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await produto.selectIdProduto(id)
            return res.json({produto:result})
        } catch (error) {
            return res.json({result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await produto.selectInnerJoin()
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }
    }
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await produto.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }
}

export { ProdutoController }