import { Itemcarrinho } from "../model/ItemCarrinho.js";
const itemcarrinho = new Itemcarrinho()
class ItemCarrinhoController{
    async verifyIdBody(req, res, next){
        var {id, produtoId, carrinhoId} = req.body
        console.log("Id: ",id);
        
        if (isNaN(id) ||isNaN(produtoId) || isNaN(carrinhoId)) {
            return res.json({erro: 'O id do produto e do carrinho deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await itemcarrinho.selectIdItemcarrinho(id)
                if (result.length > 0) {
                    req.id = id
                    req.produtoId = produtoId
                    req.carrinhoId = carrinhoId
                }else{
                    return res.json({erro: 'Item de Carrinho não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyIdParams(req, res, next){
        var {id, produtoId, carrinhoId} = req.params
        id = parseInt(id)
        produtoId = parseInt(produtoId)
        carrinhoId = parseInt(carrinhoId)
        if (isNaN(id) ||isNaN(produtoId) || isNaN(carrinhoId)) {
            return res.json({erro: 'O id do produto e do carrinho deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await itemcarrinho.selectIdItemcarrinho(id)
                if (result.length > 0) {
                    req.id = id
                    req.produtoId = produtoId
                    req.carrinhoId = carrinhoId
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyData(req, res, next){
        var {produtoId, quantidade, carrinhoId} = req.body
        if(isNaN(produtoId) || isNaN(carrinhoId) || isNaN(quantidade)){
            return res.json({erro: 'O Id do produto e do carrinho deve ser número e campo não deve estar vazio'})
        }else{
            try {
                console.log("Carrinho: ", produtoId);
                
                var result = await itemcarrinho.selectCarrinhoItemcarrinho(produtoId)
                if (result.length <= 0) {
                    req.id = id
                    req.produtoId = produtoId
                    req.carrinhoId = carrinhoId 
                    req.quantidade = quantidade
                }else{
                    return res.status(406).json({erro: 'Item de carrinho já existe'})
                }
                next()            
            } catch (error) {
                return error
            }
        }       
         
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {produtoId, quantidade, carrinhoId} = req
        try {
            var result = await itemcarrinho.insert(produtoId, quantidade, carrinhoId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Itemcarrinho inserida",result})
        }
    }
    async update(req, res){
        var {produtoId, quantidade, carrinhoId} = req 
        var {id} = req

        if (typeof(id) !== Number) {
            console.log("Is number:",id, ", TypeOf: ", typeof(id));
        }      
        try {
            var result = await itemcarrinho.update(id, produtoId, quantidade, carrinhoId)
            return res.json({mensagem: 'itemcarrinho alterada',result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async select(req, res){  
        try {
            var result = await itemcarrinho.select()
            return res.json({itemcarrinho: result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await itemcarrinho.delete(id)
                return res.json({mensagem: "Item de carrinho deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
//FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await itemcarrinho.selectIdItemcarrinho(id)
            return res.json({result})
        } catch (error) {
            return res.json({itemcarrinho: result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await itemcarrinho.selectInnerJoin()
            return res.status(201).json({join: result})
        } catch (error) {
            return res.json({result})
        }
    }  
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await itemcarrinho.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }  
    
}

export { ItemCarrinhoController }