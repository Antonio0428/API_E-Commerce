import { Estoque } from "../model/Estoque.js"
var estoque = new Estoque()
class EstoqueController{

    //MIDDLEWARE
    async verifyIdBody(req, res, next){
        var {id} = req.body
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await estoque.selectProdutoId(id)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyIdParams(req, res, next){
        var {id} = req.params
        id = parseInt(id)
        if (isNaN(id)) {
            return res.json({erro: 'O id da categoria deve ser número ou campo não deve estar vazio'})
        }else{
            try {
                var result = await estoque.selectProdutoId(produtoId)
                if (result.length > 0) {
                    req.id = id
                }else{
                    return res.json({erro: 'Produto não existente'})
                }
                next()            
            } catch (error) {
                return error
            }
        } 
    }
    async verifyData(req, res, next){
        var {quantidade, produtoId} = req.body
        console.log("Id1: ", produtoId);
        if(isNaN(quantidade) || isNaN(produtoId)){
            return res.json({erro: 'A quanridade e o Id do produto deve ser número e campo não deve estar vazio'})
        }else{
            console.log("Id2: ", produtoId);
            quantidade = parseInt(quantidade)
            produtoId = parseInt(produtoId) 
            
            try {
                var result = await estoque.selectProdutoId(produtoId)
                console.log("Id3: ", produtoId);
                
                if (result.length <= 0) {
                    req.produtoId = produtoId
                    req.quantidade = quantidade
                    console.log("Id4: ", produtoId);
                }else{
                    return res.json({erro: 'Nome do produto já existe'})
                }
                next()            
            } catch (error) {
                return error
            }
        }       
         
    }
//FUNÇÃO DAS ROTAS
    async insert(req, res){
        var {quantidade, produtoId} = req
        try {
            var result = await estoque.insert(quantidade, produtoId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Produto inserida",result})
        }
    }
    async update(req, res){
        var {id, nome, preco, descricao, categoriaId} = req
        try {
            var result = await produto.update(id, nome, preco, descricao, categoriaId)
            return res.json({result})
        } catch (error) {
            return res.json({mensagem: "Produto alterado",result})
        }
    }
    async select(req, res){  
        try {
            var result = await produto.select()
            return res.json({estoques:result})
        } catch (error) {
            return res.json({error})
        }    
    }
    async delete(req, res){
        var {id} = req
            try {
                var result = await produto.delete(id)
                return res.json({mensagem: "Produto deletada", result})
            } catch (error) {
                return res.json({error})
            }
    }
    //FUNÇÃO DAS ROTAS: Seleções específicas
    async selectById(req, res){
        var {id} = req
        try {
            var result = await produto.selectIdProduto(id)
            return res.json({estoque:result})
        } catch (error) {
            return res.json({result})
        }
    }
    async selectInnerJoin(req, res){
        try {
            var result = await produto.selectInnerJoin()
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }
    }
    async selectIdInnerJoin(req, res){
        var {id} = req

        try {
            var result = await produto.selectIdInnerJoin(id)
            return res.status(201).json({result})
        } catch (error) {
            return res.json({result})
        }

    }
}

export { EstoqueController }